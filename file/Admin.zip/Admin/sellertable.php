<table class="table">
    <tbody>
        <tr>
            <th>Seller ID: </th>
            <td>SID194033</td>
        </tr>
        <tr>
            <th>Seller Name: </th>
            <td>Avdhut Akash Kamble</td>
        </tr>
        <tr>
            <th>Seller Address: </th>
            <td>H-18, Yerwada, Pune, 6</td>
        </tr>
        <tr>
            <th>Seller Phone: </th>
            <td>+91 8605677177</td>
        </tr>
        <tr>
            <th>Seller Zip Code: </th>
            <td>411006</td>
        </tr>
        <tr>
            <th>Seller Verification Status: </th>
            <td style="color: green;">Verified</td>
        </tr>
        <tr>
            <th>Average Customer Rating: </th>
            <td style="color: gold;">4.7 <i class="fa-solid fa-star"></i></td>
        </tr>
        <tr>
            <th>Total offline Revenue: </th>
            <td>Rs. 132,415,325</td>
        </tr>
        <tr>
            <th>Total offline Revenue: </th>
            <td>Rs. 132,415,325</td>
        </tr>
        <tr>
            <th>Total Online Revenue: </th>
            <td>Rs. 132,415,325</td>
        </tr>
        <tr>
            <th>Partnership Timeline: </th>
            <td>2 years, 4 months</td>
        </tr>
        <tr>
            <th>Total Customers Served: </th>
            <td>24135</td>
        </tr>
    </tbody>
</table>